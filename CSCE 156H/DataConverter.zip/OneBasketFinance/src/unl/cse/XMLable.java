package unl.cse;

public interface XMLable {

}
