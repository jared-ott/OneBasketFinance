package unl.cse;

public enum BrokerType {
	EXPERT,
	JUNIOR;
}
