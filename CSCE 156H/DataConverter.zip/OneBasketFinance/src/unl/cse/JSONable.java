package unl.cse;

public interface JSONable {

}
